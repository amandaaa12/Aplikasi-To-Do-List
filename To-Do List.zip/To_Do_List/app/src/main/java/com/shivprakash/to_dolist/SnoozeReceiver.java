package com.shivprakash.to_dolist;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;
import android.widget.Toast;

import androidx.core.app.NotificationManagerCompat;

/**
 * Receiver untuk tombol "Tunda 5 Menit" pada notifikasi reminder.
 */
public class SnoozeReceiver extends BroadcastReceiver {

    public static final String ACTION_SNOOZE = "com.shivprakash.to_dolist.ACTION_SNOOZE";
    public static final String EXTRA_NOTIFICATION_ID = "extra_notification_id"; // ⭐ Konstanta untuk ID Notifikasi
    private static final int SNOOZE_DELAY_MINUTES = 5;

    @Override
    public void onReceive(Context context, Intent intent) {
        try {
            if (intent == null || !ACTION_SNOOZE.equals(intent.getAction())) return;

            String taskId = intent.getStringExtra(ReminderReceiver.EXTRA_TASK_ID);
            String taskName = intent.getStringExtra(ReminderReceiver.EXTRA_TASK_NAME);
            int notificationId = intent.getIntExtra(EXTRA_NOTIFICATION_ID, -1); // ⭐ Ambil ID Notifikasi

            // ... (Log, Cancel, Stop Alarm Sound Logic) ...

            // ✅ Batalkan notifikasi lama
            if (notificationId != -1) {
                NotificationManagerCompat.from(context).cancel(notificationId);
            }

            // ✅ Kirim broadcast ke ReminderReceiver untuk menghentikan suara alarm aktif (jika ada)
            Intent stopIntent = new Intent(context, ReminderReceiver.class);
            stopIntent.setAction(ReminderReceiver.ACTION_STOP_ALARM_SOUND);
            context.sendBroadcast(stopIntent);


            // ✅ Validasi data
            if (taskId == null || taskId.trim().isEmpty()) {
                Toast.makeText(context, "Gagal menunda reminder (ID kosong)", Toast.LENGTH_SHORT).show();
                Log.w("SnoozeReceiver", "❌ taskId null atau kosong — tidak bisa menjadwalkan ulang.");
                return;
            }

            // ... (Jadwal Ulang Alarm Logic) ...

            // ✅ Hitung waktu snooze baru (5 menit dari sekarang)
            long triggerTime = System.currentTimeMillis() + (SNOOZE_DELAY_MINUTES * 60 * 1000L);

            // ✅ Buat intent baru untuk ReminderReceiver (Alarm yang baru)
            Intent newIntent = new Intent(context, ReminderReceiver.class);
            newIntent.setAction("com.shivprakash.to_dolist.REMINDER_ALARM_SNOOZED");
            newIntent.putExtra(ReminderReceiver.EXTRA_TASK_ID, taskId);
            newIntent.putExtra(ReminderReceiver.EXTRA_TASK_NAME, taskName);
            newIntent.putExtra(ReminderReceiver.EXTRA_IS_EARLY, false); // Alarm tunda harus di set ke FALSE (langsung memicu)

            // ✅ PendingIntent unik berdasarkan taskId
            PendingIntent pendingIntent = PendingIntent.getBroadcast(
                    context,
                    ("snooze_alarm_" + taskId).hashCode(), // ID unik untuk alarm baru
                    newIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );

            // ✅ Jadwalkan ulang alarm menggunakan AlarmManager
            AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (alarmManager != null) {
                // ... (Logic setExact/setExactAndAllowWhileIdle) ...
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    if (alarmManager.canScheduleExactAlarms()) {
                        alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerTime, pendingIntent);
                    } else {
                        alarmManager.set(AlarmManager.RTC_WAKEUP, triggerTime, pendingIntent);
                    }
                } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerTime, pendingIntent);
                } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    alarmManager.setExact(AlarmManager.RTC_WAKEUP, triggerTime, pendingIntent);
                } else {
                    alarmManager.set(AlarmManager.RTC_WAKEUP, triggerTime, pendingIntent);
                }
            } else {
                Log.e("SnoozeReceiver", "⚠️ AlarmManager null, tidak bisa menjadwalkan ulang reminder.");
                return;
            }

            // ✅ Feedback ke pengguna
            Toast.makeText(context,
                    "Reminder \"" + (taskName != null ? taskName : "Tugas") + "\" ditunda " +
                            SNOOZE_DELAY_MINUTES + " menit.",
                    Toast.LENGTH_LONG).show();

            Log.d("SnoozeReceiver", "✅ Reminder '" + taskName + "' dijadwalkan ulang dalam 5 menit.");

        } catch (Exception e) {
            Log.e("SnoozeReceiver", "❌ Error di SnoozeReceiver: " + e.getMessage(), e);
        }
    }
}