package com.shivprakash.to_dolist;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

/**
 * BootReceiver dijalankan setiap kali perangkat selesai melakukan booting (reboot).
 * Tujuannya untuk menjadwalkan ulang semua reminder yang tersimpan di database.
 * Untuk sementara, receiver ini hanya menampilkan log agar tidak error.
 */
public class BootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || intent.getAction() == null) return;

        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            Log.d("BootReceiver", "Perangkat selesai booting. Anda bisa menjadwalkan ulang reminder di sini.");

            // Untuk debugging, tampilkan toast kecil
            Toast.makeText(context, "Sistem baru dinyalakan, reminder siap diaktifkan ulang.", Toast.LENGTH_LONG).show();

            // TODO (opsional):
            // Di sini kamu bisa ambil semua data reminder dari SQLite
            // lalu panggil kembali AddTaskActivity.scheduleReminder() untuk masing-masing tugas.
        }
    }
}
