package com.shivprakash.to_dolist;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.widget.CalendarView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private TaskDBHelper dbHelper;
    private List<Data> taskData;
    private TaskAdapter adapter;

    private static final int NOTIF_PERMISSION_REQUEST = 101;
    private static final String TAG = "MainActivity";

    @SuppressLint("MissingPermission")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // === Minta izin notifikasi (Android 13+) ===
        requestNotificationPermission();

        // === Buat NotificationChannel (Android O+) ===
        createNotificationChannel();

        // === Inisialisasi database lokal ===
        dbHelper = new TaskDBHelper(this);
        taskData = new ArrayList<>();

        // === RecyclerView setup ===
        RecyclerView recyclerView = findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new TaskAdapter(this, taskData);
        recyclerView.setAdapter(adapter);

        // === FAB Tambah Tugas ===
        FloatingActionButton fabAdd = findViewById(R.id.fab_add_task);
        fabAdd.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddTaskActivity.class);
            startActivity(intent);
        });

        // === FAB Logout ===
        FloatingActionButton fabLogout = findViewById(R.id.fab_logout);
        fabLogout.setOnClickListener(v -> {
            FirebaseAuth.getInstance().signOut();
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            Toast.makeText(MainActivity.this, "Logout berhasil", Toast.LENGTH_SHORT).show();
            finish();
        });

        // === CalendarView ===
        CalendarView calendarView = findViewById(R.id.calendarView);
        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) ->
                Toast.makeText(this,
                        "Tanggal: " + dayOfMonth + "/" + (month + 1) + "/" + year,
                        Toast.LENGTH_SHORT).show());

        // === Listener task item ===
        adapter.setOnItemClickListener(new TaskAdapter.OnItemClickListener() {
            @Override
            public void onEditClick(int position) {
                if (position < 0 || position >= taskData.size()) return;
                long idToEdit = taskData.get(position).getId();
                Intent intent = new Intent(MainActivity.this, editTask.class);
                intent.putExtra("TASK_ID", idToEdit);
                startActivity(intent);
            }

            @Override
            public void onDeleteClick(int position) {
                if (position < 0 || position >= taskData.size()) return;
                deleteTask(position);
                Toast.makeText(MainActivity.this, "Tugas dihapus", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCheckboxClick(int position) {
                if (position < 0 || position >= taskData.size()) return;
                markTaskAsComplete(position);
                Toast.makeText(MainActivity.this, "Tugas selesai", Toast.LENGTH_SHORT).show();
            }
        });

        // === Muat data tugas ===
        loadTasksFromSQLite(taskData);

        // === Tangani intent reminder ===
        if (getIntent() != null && getIntent().hasExtra("deadline")) {
            String taskName = getIntent().getStringExtra("taskName");
            long deadlineMillis = getIntent().getLongExtra("deadline", -1);
            if (deadlineMillis > 0 && taskName != null) {
                scheduleReminder(taskName, deadlineMillis);
            }
        }
    }

    // === Izin & Notifikasi ===
    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(
                        this,
                        new String[]{Manifest.permission.POST_NOTIFICATIONS},
                        NOTIF_PERMISSION_REQUEST
                );
            }
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    "todo_channel",
                    "To-Do Notifications",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Channel untuk To-Do List");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadTasksFromSQLite(taskData);
    }

    // === Database SQLite ===
    @SuppressLint("Range")
    public void loadTasksFromSQLite(List<Data> data) {
        data.clear();
        SQLiteDatabase db = null;
        Cursor cursor = null;
        try {
            db = dbHelper.getReadableDatabase();
            cursor = db.rawQuery("SELECT * FROM " + TaskContract.TaskEntry.TABLE_NAME, null);
            if (cursor.moveToFirst()) {
                do {
                    long id = cursor.getLong(cursor.getColumnIndexOrThrow(TaskContract.TaskEntry._ID));
                    String taskName = cursor.getString(cursor.getColumnIndexOrThrow(TaskContract.TaskEntry.COLUMN_TASK));
                    String taskDate = cursor.getString(cursor.getColumnIndexOrThrow(TaskContract.TaskEntry.COLUMN_DUE_DATE));
                    String taskTime = cursor.getString(cursor.getColumnIndexOrThrow(TaskContract.TaskEntry.COLUMN_DUE_TIME));
                    String category = cursor.getString(cursor.getColumnIndexOrThrow(TaskContract.TaskEntry.COLUMN_CATEGORY));
                    String priority = cursor.getString(cursor.getColumnIndexOrThrow(TaskContract.TaskEntry.COLUMN_PRIORITY));
                    String notes = cursor.getString(cursor.getColumnIndexOrThrow(TaskContract.TaskEntry.COLUMN_NOTES));
                    data.add(new Data(id, taskName, taskDate, taskTime, category, priority, notes));
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG, "Error load data: " + e.getMessage(), e);
        } finally {
            if (cursor != null) cursor.close();
            if (db != null) db.close();
        }
        adapter.notifyDataSetChanged();
    }

    public void markTaskAsComplete(int position) {
        if (position < 0 || position >= taskData.size()) return;
        long id = taskData.get(position).getId();
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(TaskContract.TaskEntry.COLUMN_COMPLETED, 1);
        db.update(TaskContract.TaskEntry.TABLE_NAME, values,
                TaskContract.TaskEntry._ID + "=?", new String[]{String.valueOf(id)});
        db.close();
        loadTasksFromSQLite(taskData);
    }

    public void deleteTask(int position) {
        if (position < 0 || position >= taskData.size()) return;
        long id = taskData.get(position).getId();
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete(TaskContract.TaskEntry.TABLE_NAME,
                TaskContract.TaskEntry._ID + "=?", new String[]{String.valueOf(id)});
        db.close();
        taskData.remove(position);
        adapter.notifyItemRemoved(position);
    }

    // === Reminder (Sudah diperbaiki error exact alarm) ===
    @SuppressLint("MissingPermission")
    private void scheduleReminder(String taskName, long deadlineMillis) {
        long earlyReminderTime = deadlineMillis - (10 * 60 * 1000);

        if (earlyReminderTime > System.currentTimeMillis()) {
            Intent earlyIntent = new Intent(this, ReminderReceiver.class);
            earlyIntent.putExtra(ReminderReceiver.EXTRA_TASK_NAME, taskName);
            earlyIntent.putExtra(ReminderReceiver.EXTRA_IS_EARLY, true);
            PendingIntent earlyPendingIntent = PendingIntent.getBroadcast(
                    this, taskName.hashCode(), earlyIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );
            setExactAlarm(earlyReminderTime, earlyPendingIntent);
        }

        if (deadlineMillis > System.currentTimeMillis()) {
            Intent intent = new Intent(this, ReminderReceiver.class);
            intent.putExtra(ReminderReceiver.EXTRA_TASK_NAME, taskName);
            intent.putExtra(ReminderReceiver.EXTRA_IS_EARLY, false);
            PendingIntent pendingIntent = PendingIntent.getBroadcast(
                    this, taskName.hashCode() + 1, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );
            setExactAlarm(deadlineMillis, pendingIntent);
        }
    }

    private void setExactAlarm(long timeInMillis, PendingIntent pendingIntent) {
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (alarmManager.canScheduleExactAlarms()) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timeInMillis, pendingIntent);
                    } else {
                        alarmManager.setExact(AlarmManager.RTC_WAKEUP, timeInMillis, pendingIntent);
                    }
                } else {
                    Toast.makeText(this, "Aktifkan izin exact alarm di pengaturan.", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                    intent.setData(android.net.Uri.parse("package:" + getPackageName()));
                    startActivity(intent);
                }
            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timeInMillis, pendingIntent);
                else
                    alarmManager.setExact(AlarmManager.RTC_WAKEUP, timeInMillis, pendingIntent);
            }
        } catch (SecurityException e) {
            Log.e(TAG, "Tidak punya izin exact alarm: " + e.getMessage());
        }
    }

    // === Class Data ===
    public static class Data {
        long id;
        String name, date, time, category, priority, notes;

        Data(long id, String name, String date, String time, String category, String priority, String notes) {
            this.id = id;
            this.name = name;
            this.date = date;
            this.time = time;
            this.category = category;
            this.priority = priority;
            this.notes = notes;
        }

        public long getId() { return id; }
        public String getName() { return name; }
        public String getDate() { return date; }
        public String getTime() { return time; }
        public String getCategory() { return category; }
        public String getPriority() { return priority; }
        public String getNotes() { return notes; }
    }
}
