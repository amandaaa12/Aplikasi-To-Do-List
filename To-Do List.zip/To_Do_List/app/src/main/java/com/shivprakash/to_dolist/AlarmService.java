package com.shivprakash.to_dolist;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

public class AlarmService extends Service {

    public static final String ACTION_STOP = "com.shivprakash.to_dolist.ACTION_STOP_ALARM";
    public static final String ACTION_SNOOZE = "com.shivprakash.to_dolist.ACTION_SNOOZE_ALARM";
    private static final String SERVICE_CHANNEL_ID = "alarm_service_channel";
    private Ringtone ringtone;
    private int foregroundNotifId = 1;

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    SERVICE_CHANNEL_ID,
                    "Alarm Service Channel",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Service channel untuk memutar alarm");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String taskName = intent != null ? intent.getStringExtra(ReminderReceiver.EXTRA_TASK_NAME) : "Tugas";
        int notifId = intent != null ? intent.getIntExtra("notification_id", (int) System.currentTimeMillis()) : (int) System.currentTimeMillis();

        foregroundNotifId = notifId;

        // buat notification foreground (tampil saat service berjalan)
        NotificationCompat.Builder nb = new NotificationCompat.Builder(this, SERVICE_CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("Alarm: " + taskName)
                .setContentText("Menyalakan alarm...")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(false)
                .setOngoing(true);

        // start foreground (harus cepat)
        startForeground(foregroundNotifId, nb.build());

        // mainkan ringtone default TYPE_ALARM
        try {
            Uri alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            if (alarmSound == null) alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            ringtone = RingtoneManager.getRingtone(getApplicationContext(), alarmSound);

            // jika API >= L, set audio attributes via internal (Ringtone tidak punya setter audioAttributes)
            // play ringtone
            if (ringtone != null && !ringtone.isPlaying()) {
                ringtone.play();
            }
        } catch (Exception e) {
            Log.e("AlarmService", "Gagal memutar ringtone: " + e.getMessage());
        }

        // Jika intent action stop/snooze
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopAlarm();
            stopSelf();
            return START_NOT_STICKY;
        } else if (intent != null && ACTION_SNOOZE.equals(intent.getAction())) {
            // triggering snooze: forward to SnoozeReceiver (so existing logic handles snooze)
            Intent snooze = new Intent(getApplicationContext(), SnoozeReceiver.class);
            snooze.setAction(SnoozeReceiver.ACTION_SNOOZE);
            snooze.putExtra(ReminderReceiver.EXTRA_TASK_ID, intent.getStringExtra(ReminderReceiver.EXTRA_TASK_ID));
            snooze.putExtra(ReminderReceiver.EXTRA_TASK_NAME, intent.getStringExtra(ReminderReceiver.EXTRA_TASK_NAME));
            snooze.putExtra("notification_id", notifId);
            getApplicationContext().sendBroadcast(snooze);

            stopAlarm();
            stopSelf();
            return START_NOT_STICKY;
        }

        return START_STICKY;
    }

    private void stopAlarm() {
        try {
            if (ringtone != null && ringtone.isPlaying()) {
                ringtone.stop();
            }
        } catch (Exception e) {
            Log.w("AlarmService", "Error stopping ringtone: " + e.getMessage());
        }
        try {
            stopForeground(true);
        } catch (Exception ignored) {}
    }

    @Override
    public void onDestroy() {
        stopAlarm();
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}