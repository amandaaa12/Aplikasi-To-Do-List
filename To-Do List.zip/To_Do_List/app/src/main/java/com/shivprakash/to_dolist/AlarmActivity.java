package com.shivprakash.to_dolist;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

/**
 * Activity sederhana yang muncul full-screen saat alarm.
 * Menyediakan tombol Dismiss dan Snooze.
 */
public class AlarmActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Tampilkan di atas lockscreen & hidupkan layar (API level sesuai)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON |
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }

        String taskName = getIntent().getStringExtra(ReminderReceiver.EXTRA_TASK_NAME);
        String taskId = getIntent().getStringExtra(ReminderReceiver.EXTRA_TASK_ID);

        // Buat layout sederhana programmatically supaya kamu nggak perlu XML
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(50, 100, 50, 100);
        root.setGravity(Gravity.CENTER);

        TextView tv = new TextView(this);
        tv.setTextSize(20f);
        tv.setText("Alarm: " + (taskName != null ? taskName : "Tugas"));
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(0, 0, 0, 30);

        Button snoozeBtn = new Button(this);
        snoozeBtn.setText("Tunda 5 Menit");
        snoozeBtn.setOnClickListener(v -> {
            // Kirim broadcast ke SnoozeReceiver untuk jadwalkan ulang
            Intent snooze = new Intent(this, SnoozeReceiver.class);
            snooze.setAction(SnoozeReceiver.ACTION_SNOOZE);
            snooze.putExtra(ReminderReceiver.EXTRA_TASK_ID, taskId); // ✅ Ganti ke ReminderReceiver
            snooze.putExtra(ReminderReceiver.EXTRA_TASK_NAME, taskName);
            // notification id: gunakan taskId.hashCode()
            snooze.putExtra(SnoozeReceiver.EXTRA_NOTIFICATION_ID,
                    taskId != null ? taskId.hashCode() : (int) System.currentTimeMillis());
            sendBroadcast(snooze);

            // hentikan service alarm
            Intent stopSvc = new Intent(this, AlarmService.class);
            stopSvc.setAction(AlarmService.ACTION_SNOOZE);
            stopSvc.putExtra(ReminderReceiver.EXTRA_TASK_ID, taskId);
            stopSvc.putExtra(ReminderReceiver.EXTRA_TASK_NAME, taskName);
            ContextCompat.startForegroundService(this, stopSvc);

            finish();
        });

        Button dismissBtn = new Button(this);
        dismissBtn.setText("Matikan");
        dismissBtn.setOnClickListener(v -> {
            // Stop AlarmService
            Intent stopSvc = new Intent(this, AlarmService.class);
            stopSvc.setAction(AlarmService.ACTION_STOP);
            ContextCompat.startForegroundService(this, stopSvc);
            finish();
        });

        root.addView(tv);
        root.addView(snoozeBtn);
        root.addView(dismissBtn);

        setContentView(root);
    }
}
