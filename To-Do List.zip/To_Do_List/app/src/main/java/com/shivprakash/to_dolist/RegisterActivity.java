package com.shivprakash.to_dolist;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

// Catatan: Anda tidak perlu mengimpor Firebase Auth di sini karena hanya menggunakan SQLite

public class RegisterActivity extends AppCompatActivity {

    EditText usernameInput, passwordInput;
    Button registerBtn;
    UserDBHelper dbHelper; // Digunakan untuk registrasi SQLite

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        dbHelper = new UserDBHelper(this); // Inisialisasi DB Helper
        usernameInput = findViewById(R.id.username_input);
        passwordInput = findViewById(R.id.password_input);
        registerBtn = findViewById(R.id.register_button);

        registerBtn.setOnClickListener(v -> {
            String user = usernameInput.getText().toString().trim();
            String pass = passwordInput.getText().toString().trim();

            if (user.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Isi semua kolom!", Toast.LENGTH_SHORT).show();
                return;
            }

            // >> KODE ASLI ANDA: Menggunakan SQLite <<
            if (dbHelper.registerUser(user, pass)) {
                Toast.makeText(this, "Registrasi berhasil! Silakan Login.", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, LoginActivity.class));
                finish();
            } else {
                Toast.makeText(this, "Username sudah dipakai!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}