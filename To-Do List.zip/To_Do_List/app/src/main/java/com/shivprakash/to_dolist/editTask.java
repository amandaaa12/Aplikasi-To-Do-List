package com.shivprakash.to_dolist;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.timepicker.MaterialTimePicker;
import com.google.android.material.timepicker.TimeFormat;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class editTask extends AppCompatActivity {

    private static final String TAG = "editTask";

    // Views that exist in your XML
    private TextView taskNameTextView;              // @+id/text_view_task (label used as editable field)
    private TextView selectedDateTextView;          // @+id/selected_date_text_view
    private TextView selectedTimeTextView;          // @+id/selected_time_text_view
    private Spinner categorySpinner;                // @+id/category_spinner
    private Spinner prioritySpinner;                // @+id/priority_spinner
    private EditText notesEditText;                 // @+id/notes_edit_text
    private Button selectDateButton;                // @+id/button_select_due_date
    private Button selectTimeButton;                // @+id/button_select_due_time
    private Button saveButton;                      // @+id/button_add_task  (we use this as Save/Edit)

    private TaskDBHelper dbHelper;
    private Calendar calendar;
    private int mYear, mMonth, mDay, mHour, mMinute;
    private long taskId; // DB id (_ID)
    private String taskNameValue = ""; // current task name (editable by tapping the TextView)

    private static final int EXACT_ALARM_PERMISSION_REQUEST = 202;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_task);

        // Ambil ID dari Intent (MainActivity harus mengirimkan TASK_ID long)
        taskId = getIntent().getLongExtra("TASK_ID", -1);
        if (taskId == -1) {
            Toast.makeText(this, "Task tidak ditemukan!", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Bind views sesuai XML yang kamu pakai
        taskNameTextView = findViewById(R.id.text_view_task);
        selectedDateTextView = findViewById(R.id.selected_date_text_view);
        selectedTimeTextView = findViewById(R.id.selected_time_text_view);
        categorySpinner = findViewById(R.id.category_spinner);
        prioritySpinner = findViewById(R.id.priority_spinner);
        notesEditText = findViewById(R.id.notes_edit_text);
        selectDateButton = findViewById(R.id.button_select_due_date);
        selectTimeButton = findViewById(R.id.button_select_due_time);
        saveButton = findViewById(R.id.button_add_task); // XML punya id button_add_task

        dbHelper = new TaskDBHelper(this);
        calendar = Calendar.getInstance();

        // Inisialisasi waktu default untuk date/time picker
        mYear = calendar.get(Calendar.YEAR);
        mMonth = calendar.get(Calendar.MONTH);
        mDay = calendar.get(Calendar.DAY_OF_MONTH);
        mHour = calendar.get(Calendar.HOUR_OF_DAY);
        mMinute = calendar.get(Calendar.MINUTE);

        // Set adapter spinner jika ada
        if (categorySpinner != null) {
            ArrayAdapter<CharSequence> categoryAdapter = ArrayAdapter.createFromResource(
                    this, R.array.categories_array, android.R.layout.simple_spinner_item);
            categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            categorySpinner.setAdapter(categoryAdapter);
        }
        if (prioritySpinner != null) {
            ArrayAdapter<CharSequence> priorityAdapter = ArrayAdapter.createFromResource(
                    this, R.array.priorities_array, android.R.layout.simple_spinner_item);
            priorityAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            prioritySpinner.setAdapter(priorityAdapter);
        }

        // Muat data dari DB dan tampilkan ke UI
        loadTaskData(taskId);

        // Jika user mengetuk nama tugas, tampilkan dialog untuk mengedit nama
        if (taskNameTextView != null) {
            taskNameTextView.setOnClickListener(v -> showEditTaskNameDialog());
        }

        // Date & Time pickers
        if (selectDateButton != null) selectDateButton.setOnClickListener(v -> showDatePickerDialog());
        if (selectTimeButton != null) selectTimeButton.setOnClickListener(v -> showTimePickerDialog());

        // Save (Edit Task) button: simpan perubahan
        if (saveButton != null) {
            saveButton.setOnClickListener(v -> updateTask());
        } else {
            Log.w(TAG, "Save button (button_add_task) not found in layout");
        }
    }

    // Load existing task data from DB and populate UI
    private void loadTaskData(long id) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(
                TaskContract.TaskEntry.TABLE_NAME,
                null,
                TaskContract.TaskEntry._ID + "=?",
                new String[]{String.valueOf(id)},
                null, null, null
        );

        if (cursor != null && cursor.moveToFirst()) {
            String task = cursor.getString(cursor.getColumnIndexOrThrow(TaskContract.TaskEntry.COLUMN_TASK));
            String category = cursor.getString(cursor.getColumnIndexOrThrow(TaskContract.TaskEntry.COLUMN_CATEGORY));
            String priority = cursor.getString(cursor.getColumnIndexOrThrow(TaskContract.TaskEntry.COLUMN_PRIORITY));
            String notes = cursor.getString(cursor.getColumnIndexOrThrow(TaskContract.TaskEntry.COLUMN_NOTES));
            String dueDate = cursor.getString(cursor.getColumnIndexOrThrow(TaskContract.TaskEntry.COLUMN_DUE_DATE));
            String dueTime = cursor.getString(cursor.getColumnIndexOrThrow(TaskContract.TaskEntry.COLUMN_DUE_TIME));

            // Set into UI
            if (taskNameTextView != null) {
                taskNameValue = task != null ? task : "";
                taskNameTextView.setText(taskNameValue);
            }
            if (notesEditText != null) notesEditText.setText(notes != null ? notes : "");
            if (selectedDateTextView != null) selectedDateTextView.setText(dueDate != null ? dueDate : "");
            if (selectedTimeTextView != null) {
                selectedTimeTextView.setText(dueTime != null ? dueTime : "");
                // also parse into mHour/mMinute for picker's default
                try {
                    if (dueTime != null && !dueTime.trim().isEmpty()) {
                        String[] parts = dueTime.split(":");
                        if (parts.length >= 2) {
                            mHour = Integer.parseInt(parts[0]);
                            mMinute = Integer.parseInt(parts[1]);
                        }
                    }
                } catch (Exception e) {
                    Log.w(TAG, "Cannot parse dueTime to set picker defaults: " + e.getMessage());
                }
            }

            if (categorySpinner != null) setSpinnerSelection(categorySpinner, category);
            if (prioritySpinner != null) setSpinnerSelection(prioritySpinner, priority);

            cursor.close();
        } else {
            Log.w(TAG, "No task found with id=" + id);
            Toast.makeText(this, "Data tugas tidak ditemukan.", Toast.LENGTH_SHORT).show();
        }
        db.close();
    }

    // Helper untuk memilih spinner sesuai value
    private void setSpinnerSelection(Spinner spinner, String value) {
        if (spinner == null || value == null) return;
        ArrayAdapter adapter = (ArrayAdapter) spinner.getAdapter();
        if (adapter == null) return;
        for (int i = 0; i < adapter.getCount(); i++) {
            Object item = adapter.getItem(i);
            if (item != null && value.equalsIgnoreCase(item.toString())) {
                spinner.setSelection(i);
                return;
            }
        }
    }

    // Dialog untuk edit nama tugas (karena layout awalmu hanya punya TextView)
    private void showEditTaskNameDialog() {
        final EditText input = new EditText(this);
        input.setText(taskNameValue);
        input.setSelection(taskNameValue.length());

        new AlertDialog.Builder(this)
                .setTitle("Edit Nama Tugas")
                .setView(input)
                .setPositiveButton("Simpan", (dialog, which) -> {
                    taskNameValue = input.getText().toString().trim();
                    if (taskNameTextView != null) taskNameTextView.setText(taskNameValue);
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    private void showDatePickerDialog() {
        DatePickerDialog dp = new DatePickerDialog(this,
                (view, year, month, dayOfMonth) -> {
                    mYear = year; mMonth = month; mDay = dayOfMonth;
                    if (selectedDateTextView != null)
                        selectedDateTextView.setText(String.format(Locale.getDefault(), "%02d/%02d/%04d", dayOfMonth, month + 1, year));
                }, mYear, mMonth, mDay);
        dp.show();
    }

    /**
     * Menggunakan MaterialTimePicker agar default input langsung ke keyboard (jam:menit).
     * Pastikan dependency Material Components sudah ditambahkan.
     */
    private void showTimePickerDialog() {
        // build picker with current mHour/mMinute as default
        MaterialTimePicker picker = new MaterialTimePicker.Builder()
                .setTimeFormat(TimeFormat.CLOCK_24H) // ubah ke CLOCK_12H kalau ingin AM/PM
                .setHour(mHour)
                .setMinute(mMinute)
                .setTitleText("Pilih Waktu")
                .setInputMode(MaterialTimePicker.INPUT_MODE_KEYBOARD) // langsung keyboard input
                .build();

        picker.addOnPositiveButtonClickListener(dialog -> {
            mHour = picker.getHour();
            mMinute = picker.getMinute();
            if (selectedTimeTextView != null) {
                selectedTimeTextView.setText(String.format(Locale.getDefault(), "%02d:%02d", mHour, mMinute));
            }
        });

        picker.show(getSupportFragmentManager(), "TIME_PICKER");
    }

    // Update DB & reschedule alarm
    private void updateTask() {
        // get values (use fallback if view missing)
        String task = (taskNameValue != null) ? taskNameValue.trim() : "";
        String category = (categorySpinner != null && categorySpinner.getSelectedItem() != null)
                ? categorySpinner.getSelectedItem().toString() : "";
        String priority = (prioritySpinner != null && prioritySpinner.getSelectedItem() != null)
                ? prioritySpinner.getSelectedItem().toString() : "";
        String notes = (notesEditText != null) ? notesEditText.getText().toString().trim() : "";
        String dueDate = (selectedDateTextView != null) ? selectedDateTextView.getText().toString().trim() : "";
        String dueTime = (selectedTimeTextView != null) ? selectedTimeTextView.getText().toString().trim() : "";

        if (task.isEmpty()) {
            Toast.makeText(this, "Nama tugas tidak boleh kosong. Ketuk nama tugas untuk mengubah.", Toast.LENGTH_LONG).show();
            return;
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(TaskContract.TaskEntry.COLUMN_TASK, task);
        values.put(TaskContract.TaskEntry.COLUMN_CATEGORY, category);
        values.put(TaskContract.TaskEntry.COLUMN_PRIORITY, priority);
        values.put(TaskContract.TaskEntry.COLUMN_NOTES, notes);
        values.put(TaskContract.TaskEntry.COLUMN_DUE_DATE, dueDate);
        values.put(TaskContract.TaskEntry.COLUMN_DUE_TIME, dueTime);

        int updated = db.update(TaskContract.TaskEntry.TABLE_NAME, values,
                TaskContract.TaskEntry._ID + "=?", new String[]{String.valueOf(taskId)});
        db.close();

        if (updated > 0) {
            Toast.makeText(this, "Perubahan disimpan", Toast.LENGTH_SHORT).show();

            // schedule ulang reminder (10 menit sebelumnya + on-time)
            if (!dueDate.isEmpty() && !dueTime.isEmpty()) {
                try {
                    String dateTime = dueDate + " " + dueTime;
                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault());
                    long parsed = sdf.parse(dateTime).getTime();

                    // schedule early and ontime (call ReminderReceiver via PendingIntent)
                    scheduleReminder(task, String.valueOf(taskId), parsed, true);  // 10 menit sebelum
                    scheduleReminder(task, String.valueOf(taskId), parsed, false); // on-time
                } catch (Exception e) {
                    Log.e(TAG, "Error parsing date/time: " + e.getMessage(), e);
                }
            }

            // kembali ke MainActivity
            Intent i = new Intent(this, MainActivity.class);
            i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            finish();
        } else {
            Toast.makeText(this, "Gagal memperbarui tugas", Toast.LENGTH_SHORT).show();
        }
    }

    // scheduleReminder sesuai pattern yang dipakai sebelumnya
    // scheduleReminder sesuai pattern yang dipakai sebelumnya
    private void scheduleReminder(String taskName, String taskIdStr, long deadlineMillis, boolean isEarly) {
        AlarmManager alarmManager = (AlarmManager) this.getSystemService(android.content.Context.ALARM_SERVICE);

        long triggerTime = isEarly ? (deadlineMillis - 10 * 60 * 1000L) : deadlineMillis;
        if (triggerTime < System.currentTimeMillis()) triggerTime = System.currentTimeMillis() + 5000;

        Intent intent = new Intent(this, ReminderReceiver.class);
        intent.setAction(isEarly ? "com.shivprakash.to_dolist.REMINDER_ALARM_EARLY" : "com.shivprakash.to_dolist.REMINDER_ALARM_ONTIME");
        intent.putExtra(ReminderReceiver.EXTRA_TASK_NAME, taskName);
        intent.putExtra(ReminderReceiver.EXTRA_TASK_ID, taskIdStr);
        intent.putExtra(ReminderReceiver.EXTRA_IS_EARLY, isEarly);

        PendingIntent pi = PendingIntent.getBroadcast(
                this,
                (isEarly ? ("early" + taskIdStr) : ("ontime" + taskIdStr)).hashCode(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        if (alarmManager != null) {
            boolean canScheduleExact = true;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                canScheduleExact = alarmManager.canScheduleExactAlarms();
                if (!canScheduleExact) {
                    // minta user aktifkan
                    Toast.makeText(this, "Aktifkan izin Exact Alarm agar pengingat akurat.", Toast.LENGTH_LONG).show();
                    Intent req = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                    startActivityForResult(req, EXACT_ALARM_PERMISSION_REQUEST);
                }
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (canScheduleExact) alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerTime, pi);
                else alarmManager.set(AlarmManager.RTC_WAKEUP, triggerTime, pi);
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerTime, pi);
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, triggerTime, pi);
            } else {
                alarmManager.set(AlarmManager.RTC_WAKEUP, triggerTime, pi);
            }

            Log.d(TAG, "scheduleReminder set for " + (isEarly ? "early" : "ontime") + " taskId=" + taskIdStr + " at " + triggerTime);
        } else {
            Log.e(TAG, "AlarmManager is null; cannot schedule reminder for " + taskIdStr);
        }
    }

}
