package com.shivprakash.to_dolist;

import android.Manifest;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Log;
import android.app.NotificationManager;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import com.shivprakash.to_dolist.AlarmActivity;


public class ReminderReceiver extends BroadcastReceiver {

    public static final String EXTRA_TASK_NAME = "task";
    public static final String EXTRA_IS_EARLY = "isEarly";
    public static final String EXTRA_TASK_ID = "taskId";

    public static final String ACTION_STOP_ALARM_SOUND = "com.shivprakash.to_dolist.ACTION_STOP_ALARM_SOUND";

    private static final Class<?> ALARM_ACTIVITY_CLASS = AlarmActivity.class;

    // Asumsi: Anda perlu variabel ini untuk melewati pemeriksaan pada notifikasi fallback
    private boolean isFullScreenDisplayed = false;

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;

        String action = intent.getAction();

        // ---------------------------------------------------------------------
        // 🛑 LOGIC PENGHENTIAN ALARM/SUARA (Dipicu oleh SnoozeReceiver)
        // ---------------------------------------------------------------------
        if (ACTION_STOP_ALARM_SOUND.equals(action)) {
            Log.d("ReminderReceiver", "Aksi STOP_ALARM_SOUND diterima. Menghentikan suara alarm.");
            return;
        }


        // Mendapatkan data dari Intent (Hanya jika BUKAN aksi STOP_SOUND)
        String taskName = intent.getStringExtra(EXTRA_TASK_NAME);
        boolean isEarly = intent.getBooleanExtra(EXTRA_IS_EARLY, false);
        String taskId = intent.getStringExtra(EXTRA_TASK_ID);

        // Pengecekan data untuk menghindari notifikasi "null!"
        if (taskName == null || taskName.trim().isEmpty() || taskName.equals("null")) {
            Log.w("ReminderReceiver", "Intent tanpa taskName valid diterima, abaikan.");
            return;
        }

        // ---------------------------------------------------------------------
        // 🔴 LOGIC DEADLINE (isEarly = false) -> Memicu POP-UP FULL-SCREEN
        // ---------------------------------------------------------------------
        if (!isEarly) {

            // 1. Buat Intent untuk meluncurkan Activity pop-up
            Intent fullScreenIntent = new Intent(context, ALARM_ACTIVITY_CLASS);
            fullScreenIntent.putExtra(EXTRA_TASK_NAME, taskName);
            fullScreenIntent.putExtra(EXTRA_TASK_ID, taskId);

            // Flag wajib
            fullScreenIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

            try {
                context.startActivity(fullScreenIntent);
                isFullScreenDisplayed = true; // Set flag untuk menghindari notif status bar
                Log.d("ReminderReceiver", "✅ Meluncurkan Activity Pop-up Full-Screen (DEADLINE).");
                return; // Stop di sini untuk mencegah notifikasi status bar ganda
            } catch (Exception e) {
                Log.e("ReminderReceiver", "❌ Gagal meluncurkan Activity pop-up: " + e.getMessage() + ". Fallback ke notifikasi status bar.");
                isFullScreenDisplayed = false;
            }
        }

        // ---------------------------------------------------------------------
        // --- LOGIC NOTIFIKASI STATUS BAR (Pengingat Awal atau Fallback) ---
        // ---------------------------------------------------------------------

        // Logika ini hanya dijalankan untuk isEarly=true (Pengingat 10 menit) atau jika Full Screen gagal (isFullScreenDisplayed=false)
        if (isEarly || !isFullScreenDisplayed) {

            String message = isEarly
                    ? "🔔 Pengingat Tugas: 10 menit lagi untuk menjalankan: " + taskName // ⭐ Keterangan 10 menit
                    : "🚀 Waktunya untuk menjalankan tugas: " + taskName + "!";

            Intent notificationClickIntent = new Intent(context, MainActivity.class);
            notificationClickIntent.putExtra(EXTRA_TASK_NAME, taskName);
            notificationClickIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);

            int notificationId = taskName.hashCode() + (isEarly ? 1000 : 2000);

            PendingIntent contentIntent = PendingIntent.getActivity(
                    context,
                    notificationId,
                    notificationClickIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );

            // =========================================================================
            // ⭐ KODE BARU: Tombol Tunda 5 Menit (HANYA MUNCUL JIKA isEarly=true)
            // =========================================================================
            NotificationCompat.Action snoozeAction = null;
            if (isEarly) { // Hanya muncul di notifikasi Pengingat Awal (H-10 menit)

                // 1. Buat Intent untuk SnoozeReceiver
                Intent snoozeIntent = new Intent(context, SnoozeReceiver.class);
                snoozeIntent.setAction(SnoozeReceiver.ACTION_SNOOZE);
                snoozeIntent.putExtra(EXTRA_TASK_ID, taskId);
                snoozeIntent.putExtra(EXTRA_TASK_NAME, taskName);
                // Kita perlu mengirimkan ID notifikasi agar SnoozeReceiver bisa membatalkannya
                snoozeIntent.putExtra(SnoozeReceiver.EXTRA_NOTIFICATION_ID, notificationId);

                // 2. Buat PendingIntent Tunda (ID unik)
                PendingIntent snoozePendingIntent = PendingIntent.getBroadcast(
                        context,
                        ("snooze_action_" + taskId).hashCode(),
                        snoozeIntent,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                );

                // 3. Buat Action Button
                snoozeAction = new NotificationCompat.Action.Builder(
                        android.R.drawable.ic_popup_sync, // Icon default
                        "Tunda 5 Menit", // ⭐ Teks tombol
                        snoozePendingIntent
                ).build();
            }
            // =========================================================================

            NotificationCompat.Builder builder = new NotificationCompat.Builder(context, "todo_channel")
                    .setSmallIcon(android.R.drawable.ic_popup_reminder)
                    .setContentTitle("Pengingat Tugas")
                    .setContentText(message)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setAutoCancel(true)
                    .setContentIntent(contentIntent);

            // Tambahkan Tombol Tunda jika dibuat
            if (snoozeAction != null) {
                builder.addAction(snoozeAction);
            }

            // Display Notifikasi
            try {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
                        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
                                == PackageManager.PERMISSION_GRANTED) {

                    NotificationManagerCompat.from(context)
                            .notify(notificationId, builder.build());
                    Log.d("ReminderReceiver", "Notifikasi Status Bar ditampilkan.");
                }
            } catch (Exception e) {
                Log.e("ReminderReceiver", "❌ Gagal menampilkan notifikasi: " + e.getMessage());
            }
        }
    }
}