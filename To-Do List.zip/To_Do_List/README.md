# 📝 To-Do List App (Android)

A simple yet powerful To-Do List Android application built using *Java* and *SQLite, featuring **task reminders, calendar view, and user authentication*.  
This app helps users efficiently manage daily tasks, set reminders, and organize activities with categories and priorities — all in an intuitive, user-friendly interface.

---

## 🚀 Features

### ✅ Task Management
- *Add, Edit, and Delete Tasks* — Manage your daily tasks with ease.
- *Mark as Done* — Track completed activities effortlessly.
- *Set Priority & Category* — Organize tasks by importance and type.

### ⏰ Reminder System
- *Task Alarms & Notifications* — Get notified for upcoming deadlines using AlarmManager and BroadcastReceiver.
- *Snooze Option* — Delay reminders when needed.
- *Auto-Restore* — Restores all reminders automatically after reboot.

### 📅 Calendar Integration
- Visualize upcoming tasks and due dates with the built-in *Calendar View*.

### 🔐 Authentication
- *Login & Register* — Local user accounts powered by SQLite ensure your personal task data stays private.

### 💡 Extra Features
- Material Design–inspired UI.
- Offline-first — fully functional without internet.
- Lightweight and fast.

---

## 🏗 Tech Stack

| Component | Technology |
|------------|-------------|
| *Language* | Java |
| *Database* | SQLite |
| *IDE* | Android Studio |
| *Architecture* | Activity-based MVC |
| *Reminders* | AlarmManager, BroadcastReceiver |
| *Local Storage* | SQLite via TaskDBHelper and UserDBHelper |

---

## 📂 Key Java Components

| Category | Classes |
|-----------|----------|
| *Activities* | MainActivity, AddTaskActivity, EditTask, LoginActivity, RegisterActivity, CalendarView |
| *Reminder & Notifications* | AlarmActivity, AlarmService, ReminderReceiver, SnoozeReceiver, BootReceiver |
| *Database* | TaskDBHelper, UserDBHelper, TaskContract |
| *Model & Adapter* | Task, TaskAdapter |

---

## 📸 Screenshots

| Main View | Add Task | Edit Task |
|------------|-----------|-----------|
| ![Tasks](app/Tasks.png) | ![Add Task](app/add_tasks.png) | ![Edit Task](app/edit_tasks.png) |

---

## ⚙ Installation & Usage

1. Clone this repository:
   ```bash
   git clone https://github.com/yourusername/To_Do_List.git